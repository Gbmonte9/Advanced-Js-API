
let init = () => {

    let _$ = vid => document.getElementById(vid);

    const btnProcurar = _$("btnprocurar");

    btnProcurar.addEventListener("click", () => {

        let txtpais = _$("txtpais").value;

        let link = `https://restcountries.com/v3.1/name/${txtpais}`;

        let divpais = _$("divpais");

        divpais.textContent = '';

        getJSON(link).then(elemento =>{
            elemento.forEach(pais => {

                // Lingua de Nome

                let keys = Object.keys(pais.languages);
                let key = keys[0];
                console.log(key);

                //

                // Div 1 Para Bandeira De Paises

                let bandeirapais = document.createElement('div');
                bandeirapais.className = 'bandeirapais';
                bandeirapais.id = 'bandeirapais';

                let img = document.createElement('img');
                img.src = `${pais.flags.png}`;
                img.alt = `${pais.flags.alt}`

                bandeirapais.appendChild(img);
                divpais.appendChild(bandeirapais);

                // Div 2 Para Informações De País

                // Nome do Pais

                let conteudopais = document.createElement('div');
                conteudopais.className = 'conteudopais';
                conteudopais.id = 'conteudopais';

                let h2 = document.createElement('h2');
                h2.className = 'nomeDePais';
                h2.id = 'nomeDePais';
                let nomeDePais = document.createTextNode(`${pais.name.common}`);
                h2.appendChild(nomeDePais);

                conteudopais.appendChild(h2);

                // Nome Nativo

                let pnativo = document.createElement('p');
                pnativo.className = 'nomeNativo';
                pnativo.id = 'nomeNativo';
                let nomeNativo = document.createTextNode(`Native Name: ${pais.name.nativeName[key].common}`);
                pnativo.appendChild(nomeNativo);

                conteudopais.appendChild(pnativo);

                // ============

                // População

                let ppopulacao = document.createElement('p');
                ppopulacao.className = 'ppopulacao';
                ppopulacao.id = 'ppopulacao';
                let populationNumber = parseInt(pais.population, 10);
                let numberpopulacao = document.createTextNode(`Population: ${populationNumber.toLocaleString('pt-BR')}`);
                ppopulacao.appendChild(numberpopulacao);

                conteudopais.appendChild(ppopulacao);

                //

                // Religon

                let pregion = document.createElement('p');
                pregion.className = 'pregion';
                pregion.id = 'pregion';
                let regionGlobo = document.createTextNode(`Region: ${pais.region}`);
                pregion.appendChild(regionGlobo);

                conteudopais.appendChild(pregion);

                //

                // Sub Religon

                let psubregion = document.createElement('p');
                psubregion.className = 'psubregion';
                psubregion.id = 'psubregion';
                let subregionGlobo = document.createTextNode(`Sub Region: ${pais.subregion}`);
                psubregion.appendChild(subregionGlobo);

                conteudopais.appendChild(psubregion);

                //

                // Capital

                let pcapital = document.createElement('p');
                pcapital.className = 'pcapital';
                pcapital.id = 'pcapital';
                let capitalGlobo = document.createTextNode(`Capital: ${pais.capital}`);
                pcapital.appendChild(capitalGlobo);

                conteudopais.appendChild(pcapital);

                //

                // Top Level Dominion

                let pdominion = document.createElement('p');
                pdominion.className = 'pdominion';
                pdominion.id = 'pdominion';
                let dominionlGlobo = document.createTextNode(`Top Level Domain: ${pais.tld}`);
                pdominion.appendChild(dominionlGlobo);

                conteudopais.appendChild(pdominion);
 
                //

                // Currencies

                let pcurrencie = document.createElement('p');
                pcurrencie.className = 'pcurrencie';
                pcurrencie.id = 'pcurrencie';
                
                let currencieGlobo = 'Currencies: ';

                Object.entries(pais.currencies).forEach(([key, value]) => {
                    currencieGlobo += `${value.symbol}, `;
                });
                
                currencieGlobo = currencieGlobo.slice(0, -2);

                pcurrencie.appendChild(document.createTextNode(currencieGlobo));

                conteudopais.appendChild(pcurrencie);
 
                //

                // Language

                let planguage = document.createElement('p');
                planguage.className = 'planguage';
                planguage.id = 'planguage';
                let languageGlobo = 'Languages: ';
                
                Object.entries(pais.languages).forEach(([key, value]) =>{
                    languageGlobo += `${value}, `;
                });
                
                languageGlobo = languageGlobo.slice(0, -2);

                planguage.appendChild(document.createTextNode(languageGlobo));

                conteudopais.appendChild(planguage);
 
                //
 
                divpais.appendChild(conteudopais);

            });

        }).catch(error => {
            console.error('Não Encotrado:', error.message);
            window.alert('País Não Encotrado:', txtpais); 
        });

    });

}

const getJSON = async (caminho) => {
    const resultado = await fetch(caminho);
    const dados = await resultado.json();
    return dados;
};


document.addEventListener("DOMContentLoaded", init);
