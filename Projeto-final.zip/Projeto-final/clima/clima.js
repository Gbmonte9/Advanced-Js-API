


let init = () => {
    
    let _$ = vid => document.getElementById(vid);

    const btnprocurar = _$("btnprocurar");

        btnprocurar.addEventListener("click", () => {
    
        let cidade = _$('txtcidade').value;

        let linkLatitudeELongitude = `https://nominatim.openstreetmap.org/search?q=${cidade}&format=json&limit=1`;
        
        let lat = '';
        let lon = '';
        let nomePais = '';

        getJSON(linkLatitudeELongitude).then(elemento => {
            elemento.forEach(terreno => {

                lat = terreno.lat;
                lon = terreno.lon;
                nomePais = terreno.name;
    
            });

            iniciaClima(lat, lon, nomePais);

        });

    });

};

let iniciaClima = (lat, lon, nomePais) => {

    let link = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,wind_speed_10m&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m&timezone=America/Sao_Paulo`;

    getJSON(link).then(data => {

        let _$ = vid => document.getElementById(vid);

        const tempoAtual = data.current.time;
        const intervalAtual = data.current.interval;
        const temperaturaAtual = data.current.temperature_2m;
        const wind = data.current.wind_speed_10m;
        const temperaturaPontoOrvalho = data.hourly.temperature_2m[0]; 

        const umidadeRelativa = calcularUmidadeRelativa(temperaturaAtual, temperaturaPontoOrvalho);

        console.log('Tempo atual:', tempoAtual);
        console.log('Intervalo atual:', intervalAtual);
        console.log('Temperatura atual:', temperaturaAtual, '°C');
        console.log('Umidade relativa:', umidadeRelativa.toFixed(2), '%');
        console.log('Velocidade do vento:', wind, 'km/h');

        let divtemperatura = _$("divtemperatura");

        divtemperatura.textContent = '';

        let h2Pais = document.createElement('h2');
        h2Pais.className = 'h2Pais';
        h2Pais.id = 'h2Pais';

        h2Pais.appendChild(document.createTextNode(nomePais));
        divtemperatura.appendChild(h2Pais);

        let pTemperaturaAtual = document.createElement('p');
        pTemperaturaAtual.className = 'pTemperaturaAtual';
        pTemperaturaAtual.id = 'pTemperaturaAtual';

        pTemperaturaAtual.textContent = `${temperaturaAtual} °C`;
        divtemperatura.appendChild(pTemperaturaAtual);

        //

        let pUmidadeRelativa = document.createElement('p');
        pUmidadeRelativa.className = 'pUmidadeRelativa';
        pUmidadeRelativa.id = 'pUmidadeRelativa';

        pUmidadeRelativa.textContent = `${umidadeRelativa.toFixed(2)} % `;
        divtemperatura.appendChild(pUmidadeRelativa);

        //

        let pVelocidadeVento = document.createElement('p');
        pVelocidadeVento.className = 'pVelocidadeVento';
        pVelocidadeVento.id = 'pVelocidadeVento';

        pVelocidadeVento.textContent = `${wind} km/h `;
        divtemperatura.appendChild(pVelocidadeVento);

    }).catch(error => {
        console.error('Não Encotrado:', error.message);
        window.alert('País ou Cidade Não encotrado:', link); 
    });

};

let calcularUmidadeRelativa = (temperatura, temperaturaPontoOrvalho) => {
    
    let pressaoSaturacaoVapor = (T) => {
        return 6.1078 * Math.pow(10, (7.5 * T) / (237.3 + T));
    }

    const esTemperatura = pressaoSaturacaoVapor(temperatura);
    const esPontoOrvalho = pressaoSaturacaoVapor(temperaturaPontoOrvalho);

    const umidadeRelativa = 100 * (esPontoOrvalho / esTemperatura);

    return umidadeRelativa;
}

const getJSON = async (caminho) => {
    const resultado = await fetch(caminho);
    const dados = await resultado.json();
    return dados;
};

document.addEventListener("DOMContentLoaded", init);