

let init = () => {

    let _$ = vid => document.getElementById(vid);

    const btnProcurar = _$('btnprocurar');

    btnProcurar.addEventListener("click", () => {

        let artista = _$('txtartista').value;
        let lyrics = _$('txttitulo').value;

        let link = `https://api.lyrics.ovh/v1/${artista}/${lyrics}`;

        getJSON(link).then(elemento => {
                
            let divletra = document.getElementById('divletra');

            divletra.textContent = '';

            let h2artista = document.createElement('h2');
            h2artista.className = 'h2artista';
            h2artista.id = 'h2artista';

            h2artista.appendChild(document.createTextNode(artista));
            divletra.appendChild(h2artista);

            let h3letra = document.createElement('h3');
            h3letra.className = 'h3letra';
            h3letra.id = 'h3letra';

            h3letra.appendChild(document.createTextNode(lyrics));
            divletra.appendChild(h3letra);


            let pletra = document.createElement('div');
            pletra.className = 'pletra';
            pletra.id = 'pletra';
        
            elemento.lyrics.split('\n').forEach(line => {
                let p = document.createElement('p');
                p.textContent = line;
                pletra.appendChild(p);
            });
        
            divletra.appendChild(pletra);

        }).catch(error => {
            console.error('Não Encotrado:', error.message);
            window.alert('Musica Não Encotrado:', link); 
        });


    });

};

const getJSON = async (caminho) => {
    const resultado = await fetch(caminho);
    const dados = await resultado.json();
    return dados;
};


document.addEventListener("DOMContentLoaded", init);